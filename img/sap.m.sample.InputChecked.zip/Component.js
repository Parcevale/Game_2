sap.ui.define([
	"sap/ui/core/UIComponent"
], function (UIComponent) {
	"use strict";

	return UIComponent.extend("sap.m.sample.InputChecked.Component", {

		metadata: {
			manifest: "json"
		}

	});
});